package com.cuanai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090A12)
private val Panel = Color(0xFF171827)
private val Purple = Color(0xFF9B72FF)
private val Cyan = Color(0xFF54D6E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CuanApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CuanApp() {
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Realistic Cinematic") }
    var camera by remember { mutableStateOf("Dolly In") }
    var duration by remember { mutableIntStateOf(10) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Purple, secondary = Cyan
    )) {
        Scaffold(containerColor = Night) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Purple, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("cuan.AI", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("AI CINEMATIC VIDEO STUDIO", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(color = Panel, shape = RoundedCornerShape(30.dp)) {
                        Text("FREE", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Cyan, fontWeight = FontWeight.Bold)
                    }
                }

                Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxSize().background(
                        Brush.linearGradient(listOf(Color(0xFF30205A), Color(0xFF102C40), Night)),
                        RoundedCornerShape(24.dp)
                    ))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(42.dp))
                        Text("Your next cinematic story starts here", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Tulis ide, pilih gaya, lalu generate", color = Color.LightGray, fontSize = 12.sp)
                    }
                }

                Text("CREATE VIDEO", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Deskripsikan video", color = Color.White)
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 125.dp),
                    placeholder = { Text("Contoh: Penjelajah di kota futuristik saat hujan, pencahayaan sinematik...") },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF414257),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )

                ChoiceCard("Gaya visual", listOf("Realistic Cinematic", "Anime", "3D CGI", "Hyperrealistic"), style) { style = it }
                ChoiceCard("Gerakan kamera", listOf("Dolly In", "Dolly Out", "Tracking Shot", "Drone Shot", "Pan Left", "Pan Right", "Orbit 360°", "Crane Shot", "Handheld"), camera) { camera = it }

                Text("Durasi video", color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 15, 20, 30).forEach { seconds ->
                        FilterChip(selected = duration == seconds, onClick = { duration = seconds }, label = { Text("$seconds dtk") })
                    }
                }

                Button(
                    onClick = { /* Connect this action to the backend after selecting a video API provider. */ },
                    enabled = prompt.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("GENERATE VIDEO", fontWeight = FontWeight.Bold)
                }
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("PREVIEW STATUS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("UI siap. Hubungkan backend dan API video AI untuk mengaktifkan generate.", color = Color.White, fontSize = 13.sp)
                    }
                }
                Text("Free + Premium • Durasi 10–30 detik", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ChoiceCard(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Color.White)
        options.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { option ->
                    val active = option == selected
                    Surface(
                        onClick = { onSelect(option) },
                        color = if (active) Purple.copy(alpha = .22f) else Panel,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (active) Purple else Color(0xFF34364A)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(option, Modifier.padding(12.dp), color = Color.White, fontSize = 12.sp)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

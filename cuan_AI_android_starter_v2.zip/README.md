# cuan.AI — Android Starter

This repository contains the initial Android UI and a backend skeleton for the cuan.AI cinematic video generator.

## Build an APK using GitHub Actions
1. Upload all project files while preserving folders.
2. Commit them to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build cuan.AI APK** and press **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, find **Artifacts**, and download `cuan-ai-debug-apk`.
6. Extract the ZIP artifact; it contains `app-debug.apk`.

## Important status
This is an early starter build. The Android interface is present, but the Generate button is not connected to a real AI video provider yet. To generate actual videos, a provider API and secure backend integration must be configured. Do not put private provider API keys in Android source code.

## Backend starter
Requires Node.js 20+:
```bash
cd server
npm install
npm run dev
```
The `/api/generate` endpoint currently returns HTTP 501 until a video provider is integrated.

## Android configuration
Open the `android` folder in Android Studio if available. The API base URL is a placeholder in `android/app/build.gradle.kts` and must be changed to your deployed HTTPS backend when ready.

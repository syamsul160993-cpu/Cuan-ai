require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "cuan.AI" }));

app.post("/api/generate", async (req, res) => {
  const { prompt, style, camera, duration } = req.body || {};
  if (typeof prompt !== "string" || !prompt.trim()) {
    return res.status(400).json({ error: "Prompt wajib diisi." });
  }
  if (![10, 15, 20, 30].includes(Number(duration))) {
    return res.status(400).json({ error: "Durasi harus 10, 15, 20, atau 30 detik." });
  }

  // TODO: Integrasikan API video pilihan di server ini.
  // Simpan API key provider hanya di environment backend, jangan di aplikasi Android.
  return res.status(501).json({
    error: "VIDEO_PROVIDER_NOT_CONFIGURED",
    message: "Backend aktif, tetapi provider video AI belum diintegrasikan.",
    received: { prompt, style, camera, duration: Number(duration) }
  });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`cuan.AI backend listening on ${port}`));
